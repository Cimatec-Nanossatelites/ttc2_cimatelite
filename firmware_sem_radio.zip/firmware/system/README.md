# System Management Routines
