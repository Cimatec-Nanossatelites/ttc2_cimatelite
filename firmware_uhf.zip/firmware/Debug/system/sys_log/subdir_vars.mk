################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../system/sys_log/sys_log.c \
../system/sys_log/sys_log_mutex.c \
../system/sys_log/sys_log_uart.c 

C_DEPS += \
./system/sys_log/sys_log.d \
./system/sys_log/sys_log_mutex.d \
./system/sys_log/sys_log_uart.d 

OBJS += \
./system/sys_log/sys_log.obj \
./system/sys_log/sys_log_mutex.obj \
./system/sys_log/sys_log_uart.obj 

OBJS__QUOTED += \
"system\sys_log\sys_log.obj" \
"system\sys_log\sys_log_mutex.obj" \
"system\sys_log\sys_log_uart.obj" 

C_DEPS__QUOTED += \
"system\sys_log\sys_log.d" \
"system\sys_log\sys_log_mutex.d" \
"system\sys_log\sys_log_uart.d" 

C_SRCS__QUOTED += \
"../system/sys_log/sys_log.c" \
"../system/sys_log/sys_log_mutex.c" \
"../system/sys_log/sys_log_uart.c" 


