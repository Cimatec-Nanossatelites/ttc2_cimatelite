################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../system/clocks.c \
../system/cmdpr.c \
../system/hooks.c \
../system/setup.c \
../system/system.c 

C_DEPS += \
./system/clocks.d \
./system/cmdpr.d \
./system/hooks.d \
./system/setup.d \
./system/system.d 

OBJS += \
./system/clocks.obj \
./system/cmdpr.obj \
./system/hooks.obj \
./system/setup.obj \
./system/system.obj 

OBJS__QUOTED += \
"system\clocks.obj" \
"system\cmdpr.obj" \
"system\hooks.obj" \
"system\setup.obj" \
"system\system.obj" 

C_DEPS__QUOTED += \
"system\clocks.d" \
"system\cmdpr.d" \
"system\hooks.d" \
"system\setup.d" \
"system\system.d" 

C_SRCS__QUOTED += \
"../system/clocks.c" \
"../system/cmdpr.c" \
"../system/hooks.c" \
"../system/setup.c" \
"../system/system.c" 


