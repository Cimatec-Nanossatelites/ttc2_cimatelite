################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libs/crc/crc.c 

C_DEPS += \
./libs/crc/crc.d 

OBJS += \
./libs/crc/crc.obj 

OBJS__QUOTED += \
"libs\crc\crc.obj" 

C_DEPS__QUOTED += \
"libs\crc\crc.d" 

C_SRCS__QUOTED += \
"../libs/crc/crc.c" 


