################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
libs/containers/%.obj: ../libs/containers/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: MSP430 Compiler'
	"C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/bin/cl430" -vmspx --data_model=restricted --near_data=none -Ooff --use_hw_mpy=F5 --include_path="C:/ti/ccs1281/ccs/ccs_base/msp430/include" --include_path="C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/app" --include_path="C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/app/libs" --include_path="C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware" --include_path="C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include" --include_path="C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include" --include_path="C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config" --include_path="C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/portable/CCS/MSP430X" --include_path="C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/app/libs/ngham-1.0/include" --include_path="C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/app/libs/ngham-1.0/rsclib/include" --advice:power=all --define=__MSP430F5659__ -g --c99 --printf_support=minimal --diag_warning=225 --diag_wrap=off --display_error_number --silicon_errata=CPU21 --silicon_errata=CPU22 --silicon_errata=CPU40 --preproc_with_compile --preproc_dependency="libs/containers/$(basename $(<F)).d_raw" --obj_directory="libs/containers" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


