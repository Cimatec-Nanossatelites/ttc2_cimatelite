################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libs/containers/buffer.c \
../libs/containers/queue.c 

C_DEPS += \
./libs/containers/buffer.d \
./libs/containers/queue.d 

OBJS += \
./libs/containers/buffer.obj \
./libs/containers/queue.obj 

OBJS__QUOTED += \
"libs\containers\buffer.obj" \
"libs\containers\queue.obj" 

C_DEPS__QUOTED += \
"libs\containers\buffer.d" \
"libs\containers\queue.d" 

C_SRCS__QUOTED += \
"../libs/containers/buffer.c" \
"../libs/containers/queue.c" 


