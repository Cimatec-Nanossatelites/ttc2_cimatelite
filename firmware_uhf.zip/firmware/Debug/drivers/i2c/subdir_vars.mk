################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/i2c/i2c.c 

C_DEPS += \
./drivers/i2c/i2c.d 

OBJS += \
./drivers/i2c/i2c.obj 

OBJS__QUOTED += \
"drivers\i2c\i2c.obj" 

C_DEPS__QUOTED += \
"drivers\i2c\i2c.d" 

C_SRCS__QUOTED += \
"../drivers/i2c/i2c.c" 


