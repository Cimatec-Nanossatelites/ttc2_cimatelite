################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/spi_slave/spi_slave.c 

C_DEPS += \
./drivers/spi_slave/spi_slave.d 

OBJS += \
./drivers/spi_slave/spi_slave.obj 

OBJS__QUOTED += \
"drivers\spi_slave\spi_slave.obj" 

C_DEPS__QUOTED += \
"drivers\spi_slave\spi_slave.d" 

C_SRCS__QUOTED += \
"../drivers/spi_slave/spi_slave.c" 


