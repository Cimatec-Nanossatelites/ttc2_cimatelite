################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/tca4311a/tca4311a.c 

C_DEPS += \
./drivers/tca4311a/tca4311a.d 

OBJS += \
./drivers/tca4311a/tca4311a.obj 

OBJS__QUOTED += \
"drivers\tca4311a\tca4311a.obj" 

C_DEPS__QUOTED += \
"drivers\tca4311a\tca4311a.d" 

C_SRCS__QUOTED += \
"../drivers/tca4311a/tca4311a.c" 


