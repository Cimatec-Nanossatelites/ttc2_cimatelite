################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/wdt/wdt.c 

C_DEPS += \
./drivers/wdt/wdt.d 

OBJS += \
./drivers/wdt/wdt.obj 

OBJS__QUOTED += \
"drivers\wdt\wdt.obj" 

C_DEPS__QUOTED += \
"drivers\wdt\wdt.d" 

C_SRCS__QUOTED += \
"../drivers/wdt/wdt.c" 


