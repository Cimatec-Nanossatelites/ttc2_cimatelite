################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/isis_antenna/isis_antenna.c \
../drivers/isis_antenna/isis_antenna_delay.c \
../drivers/isis_antenna/isis_antenna_i2c.c 

C_DEPS += \
./drivers/isis_antenna/isis_antenna.d \
./drivers/isis_antenna/isis_antenna_delay.d \
./drivers/isis_antenna/isis_antenna_i2c.d 

OBJS += \
./drivers/isis_antenna/isis_antenna.obj \
./drivers/isis_antenna/isis_antenna_delay.obj \
./drivers/isis_antenna/isis_antenna_i2c.obj 

OBJS__QUOTED += \
"drivers\isis_antenna\isis_antenna.obj" \
"drivers\isis_antenna\isis_antenna_delay.obj" \
"drivers\isis_antenna\isis_antenna_i2c.obj" 

C_DEPS__QUOTED += \
"drivers\isis_antenna\isis_antenna.d" \
"drivers\isis_antenna\isis_antenna_delay.d" \
"drivers\isis_antenna\isis_antenna_i2c.d" 

C_SRCS__QUOTED += \
"../drivers/isis_antenna/isis_antenna.c" \
"../drivers/isis_antenna/isis_antenna_delay.c" \
"../drivers/isis_antenna/isis_antenna_i2c.c" 


