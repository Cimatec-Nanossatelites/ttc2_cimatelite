################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/tps382x/tps382x.c 

C_DEPS += \
./drivers/tps382x/tps382x.d 

OBJS += \
./drivers/tps382x/tps382x.obj 

OBJS__QUOTED += \
"drivers\tps382x\tps382x.obj" 

C_DEPS__QUOTED += \
"drivers\tps382x\tps382x.d" 

C_SRCS__QUOTED += \
"../drivers/tps382x/tps382x.c" 


