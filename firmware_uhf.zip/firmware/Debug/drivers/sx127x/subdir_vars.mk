################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/sx127x/sx127x.c \
../drivers/sx127x/sx127x_delay.c \
../drivers/sx127x/sx127x_gpio.c \
../drivers/sx127x/sx127x_spi.c 

C_DEPS += \
./drivers/sx127x/sx127x.d \
./drivers/sx127x/sx127x_delay.d \
./drivers/sx127x/sx127x_gpio.d \
./drivers/sx127x/sx127x_spi.d 

OBJS += \
./drivers/sx127x/sx127x.obj \
./drivers/sx127x/sx127x_delay.obj \
./drivers/sx127x/sx127x_gpio.obj \
./drivers/sx127x/sx127x_spi.obj 

OBJS__QUOTED += \
"drivers\sx127x\sx127x.obj" \
"drivers\sx127x\sx127x_delay.obj" \
"drivers\sx127x\sx127x_gpio.obj" \
"drivers\sx127x\sx127x_spi.obj" 

C_DEPS__QUOTED += \
"drivers\sx127x\sx127x.d" \
"drivers\sx127x\sx127x_delay.d" \
"drivers\sx127x\sx127x_gpio.d" \
"drivers\sx127x\sx127x_spi.d" 

C_SRCS__QUOTED += \
"../drivers/sx127x/sx127x.c" \
"../drivers/sx127x/sx127x_delay.c" \
"../drivers/sx127x/sx127x_gpio.c" \
"../drivers/sx127x/sx127x_spi.c" 


