################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/flash/flash.c \
../drivers/flash/flash_mutex.c 

C_DEPS += \
./drivers/flash/flash.d \
./drivers/flash/flash_mutex.d 

OBJS += \
./drivers/flash/flash.obj \
./drivers/flash/flash_mutex.obj 

OBJS__QUOTED += \
"drivers\flash\flash.obj" \
"drivers\flash\flash_mutex.obj" 

C_DEPS__QUOTED += \
"drivers\flash\flash.d" \
"drivers\flash\flash_mutex.d" 

C_SRCS__QUOTED += \
"../drivers/flash/flash.c" \
"../drivers/flash/flash_mutex.c" 


