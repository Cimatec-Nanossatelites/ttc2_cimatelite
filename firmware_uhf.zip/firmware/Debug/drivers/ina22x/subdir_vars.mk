################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/ina22x/ina22x.c 

C_DEPS += \
./drivers/ina22x/ina22x.d 

OBJS += \
./drivers/ina22x/ina22x.obj 

OBJS__QUOTED += \
"drivers\ina22x\ina22x.obj" 

C_DEPS__QUOTED += \
"drivers\ina22x\ina22x.d" 

C_SRCS__QUOTED += \
"../drivers/ina22x/ina22x.c" 


