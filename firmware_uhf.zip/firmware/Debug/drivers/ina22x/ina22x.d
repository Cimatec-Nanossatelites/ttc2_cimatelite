# FIXED

drivers/ina22x/ina22x.obj: ../drivers/ina22x/ina22x.c
drivers/ina22x/ina22x.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/system/sys_log/sys_log.h
drivers/ina22x/ina22x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h
drivers/ina22x/ina22x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
drivers/ina22x/ina22x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
drivers/ina22x/ina22x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h
drivers/ina22x/ina22x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h
drivers/ina22x/ina22x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
drivers/ina22x/ina22x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h
drivers/ina22x/ina22x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h
drivers/ina22x/ina22x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h
drivers/ina22x/ina22x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h
drivers/ina22x/ina22x.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/drivers/i2c/i2c.h
drivers/ina22x/ina22x.obj: ../drivers/ina22x/ina22x.h

../drivers/ina22x/ina22x.c:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/system/sys_log/sys_log.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/drivers/i2c/i2c.h:

../drivers/ina22x/ina22x.h:

