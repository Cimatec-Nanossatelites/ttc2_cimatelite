################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/spi/spi.c 

C_DEPS += \
./drivers/spi/spi.d 

OBJS += \
./drivers/spi/spi.obj 

OBJS__QUOTED += \
"drivers\spi\spi.obj" 

C_DEPS__QUOTED += \
"drivers\spi\spi.d" 

C_SRCS__QUOTED += \
"../drivers/spi/spi.c" 


