# FIXED

drivers/spi/spi.obj: ../drivers/spi/spi.c
drivers/spi/spi.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/usci_a_spi.h
drivers/spi/spi.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/inc/hw_memmap.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5659.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5xx_6xxgeneric.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h
drivers/spi/spi.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdbool.h
drivers/spi/spi.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/usci_b_spi.h
drivers/spi/spi.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/gpio.h
drivers/spi/spi.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/ucs.h
drivers/spi/spi.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config/config.h
drivers/spi/spi.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/system/sys_log/sys_log.h
drivers/spi/spi.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/drivers/gpio/gpio.h
drivers/spi/spi.obj: ../drivers/spi/spi.h

../drivers/spi/spi.c:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/usci_a_spi.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/inc/hw_memmap.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5659.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5xx_6xxgeneric.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdbool.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/usci_b_spi.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/gpio.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/ucs.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config/config.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/system/sys_log/sys_log.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/drivers/gpio/gpio.h:

../drivers/spi/spi.h:

