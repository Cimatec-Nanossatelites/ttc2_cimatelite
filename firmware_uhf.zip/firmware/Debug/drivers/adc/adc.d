# FIXED

drivers/adc/adc.obj: ../drivers/adc/adc.c
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdbool.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
drivers/adc/adc.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/gpio.h
drivers/adc/adc.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/inc/hw_memmap.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5659.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5xx_6xxgeneric.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h
drivers/adc/adc.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h
drivers/adc/adc.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/adc10_a.h
drivers/adc/adc.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/adc12_a.h
drivers/adc/adc.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/ref.h
drivers/adc/adc.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/tlv.h
drivers/adc/adc.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config/config.h
drivers/adc/adc.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/system/sys_log/sys_log.h
drivers/adc/adc.obj: ../drivers/adc/adc.h

../drivers/adc/adc.c:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdbool.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/gpio.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/inc/hw_memmap.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5659.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5xx_6xxgeneric.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/adc10_a.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/adc12_a.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/ref.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/hal/tlv.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config/config.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/system/sys_log/sys_log.h:

../drivers/adc/adc.h:

