################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/adc/adc.c \
../drivers/adc/adc_delay.c 

C_DEPS += \
./drivers/adc/adc.d \
./drivers/adc/adc_delay.d 

OBJS += \
./drivers/adc/adc.obj \
./drivers/adc/adc_delay.obj 

OBJS__QUOTED += \
"drivers\adc\adc.obj" \
"drivers\adc\adc_delay.obj" 

C_DEPS__QUOTED += \
"drivers\adc\adc.d" \
"drivers\adc\adc_delay.d" 

C_SRCS__QUOTED += \
"../drivers/adc/adc.c" \
"../drivers/adc/adc_delay.c" 


