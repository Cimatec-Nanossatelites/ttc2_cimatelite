# FIXED

drivers/si446x/si446x.obj: ../drivers/si446x/si446x.c
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/string.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/xlocale/_string.h
drivers/si446x/si446x.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config/config.h
drivers/si446x/si446x.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config/radio_1_config.h
drivers/si446x/si446x.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/system/sys_log/sys_log.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h
drivers/si446x/si446x.obj: ../drivers/si446x/si446x.h
drivers/si446x/si446x.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdbool.h
drivers/si446x/si446x.obj: ../drivers/si446x/si446x_config.h
drivers/si446x/si446x.obj: ../drivers/si446x/si446x_registers.h

../drivers/si446x/si446x.c:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/string.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/xlocale/_string.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config/config.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config/radio_1_config.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/system/sys_log/sys_log.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h:

../drivers/si446x/si446x.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdbool.h:

../drivers/si446x/si446x_config.h:

../drivers/si446x/si446x_registers.h:

