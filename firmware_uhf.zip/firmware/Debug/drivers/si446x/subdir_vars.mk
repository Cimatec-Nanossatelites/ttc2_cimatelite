################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/si446x/si446x.c \
../drivers/si446x/si446x_delay.c \
../drivers/si446x/si446x_gpio.c \
../drivers/si446x/si446x_mutex.c \
../drivers/si446x/si446x_spi.c 

C_DEPS += \
./drivers/si446x/si446x.d \
./drivers/si446x/si446x_delay.d \
./drivers/si446x/si446x_gpio.d \
./drivers/si446x/si446x_mutex.d \
./drivers/si446x/si446x_spi.d 

OBJS += \
./drivers/si446x/si446x.obj \
./drivers/si446x/si446x_delay.obj \
./drivers/si446x/si446x_gpio.obj \
./drivers/si446x/si446x_mutex.obj \
./drivers/si446x/si446x_spi.obj 

OBJS__QUOTED += \
"drivers\si446x\si446x.obj" \
"drivers\si446x\si446x_delay.obj" \
"drivers\si446x\si446x_gpio.obj" \
"drivers\si446x\si446x_mutex.obj" \
"drivers\si446x\si446x_spi.obj" 

C_DEPS__QUOTED += \
"drivers\si446x\si446x.d" \
"drivers\si446x\si446x_delay.d" \
"drivers\si446x\si446x_gpio.d" \
"drivers\si446x\si446x_mutex.d" \
"drivers\si446x\si446x_spi.d" 

C_SRCS__QUOTED += \
"../drivers/si446x/si446x.c" \
"../drivers/si446x/si446x_delay.c" \
"../drivers/si446x/si446x_gpio.c" \
"../drivers/si446x/si446x_mutex.c" \
"../drivers/si446x/si446x_spi.c" 


