################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../drivers/gpio/gpio.c 

C_DEPS += \
./drivers/gpio/gpio.d 

OBJS += \
./drivers/gpio/gpio.obj 

OBJS__QUOTED += \
"drivers\gpio\gpio.obj" 

C_DEPS__QUOTED += \
"drivers\gpio\gpio.d" 

C_SRCS__QUOTED += \
"../drivers/gpio/gpio.c" 


