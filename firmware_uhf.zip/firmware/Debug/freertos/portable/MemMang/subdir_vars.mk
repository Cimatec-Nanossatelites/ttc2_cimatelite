################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../freertos/portable/MemMang/heap_1.c 

C_DEPS += \
./freertos/portable/MemMang/heap_1.d 

OBJS += \
./freertos/portable/MemMang/heap_1.obj 

OBJS__QUOTED += \
"freertos\portable\MemMang\heap_1.obj" 

C_DEPS__QUOTED += \
"freertos\portable\MemMang\heap_1.d" 

C_SRCS__QUOTED += \
"../freertos/portable/MemMang/heap_1.c" 


