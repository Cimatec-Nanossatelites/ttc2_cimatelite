################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../freertos/portable/Common/mpu_wrappers.c 

C_DEPS += \
./freertos/portable/Common/mpu_wrappers.d 

OBJS += \
./freertos/portable/Common/mpu_wrappers.obj 

OBJS__QUOTED += \
"freertos\portable\Common\mpu_wrappers.obj" 

C_DEPS__QUOTED += \
"freertos\portable\Common\mpu_wrappers.d" 

C_SRCS__QUOTED += \
"../freertos/portable/Common/mpu_wrappers.c" 


