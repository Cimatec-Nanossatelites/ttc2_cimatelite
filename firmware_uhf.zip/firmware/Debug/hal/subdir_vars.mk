################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../hal/adc10_a.c \
../hal/adc12_a.c \
../hal/aes.c \
../hal/battbak.c \
../hal/comp_b.c \
../hal/crc.c \
../hal/ctsd16.c \
../hal/dac12_a.c \
../hal/dma.c \
../hal/eusci_a_spi.c \
../hal/eusci_a_uart.c \
../hal/eusci_b_i2c.c \
../hal/eusci_b_spi.c \
../hal/flashctl.c \
../hal/gpio.c \
../hal/lcd_b.c \
../hal/lcd_c.c \
../hal/ldopwr.c \
../hal/mpy32.c \
../hal/oa.c \
../hal/pmap.c \
../hal/pmm.c \
../hal/ram.c \
../hal/ref.c \
../hal/rtc_a.c \
../hal/rtc_b.c \
../hal/rtc_c.c \
../hal/sd24_b.c \
../hal/sfr.c \
../hal/sysctl.c \
../hal/tec.c \
../hal/timer_a.c \
../hal/timer_b.c \
../hal/timer_d.c \
../hal/tlv.c \
../hal/ucs.c \
../hal/usci_a_spi.c \
../hal/usci_a_uart.c \
../hal/usci_b_i2c.c \
../hal/usci_b_spi.c \
../hal/wdt_a.c 

C_DEPS += \
./hal/adc10_a.d \
./hal/adc12_a.d \
./hal/aes.d \
./hal/battbak.d \
./hal/comp_b.d \
./hal/crc.d \
./hal/ctsd16.d \
./hal/dac12_a.d \
./hal/dma.d \
./hal/eusci_a_spi.d \
./hal/eusci_a_uart.d \
./hal/eusci_b_i2c.d \
./hal/eusci_b_spi.d \
./hal/flashctl.d \
./hal/gpio.d \
./hal/lcd_b.d \
./hal/lcd_c.d \
./hal/ldopwr.d \
./hal/mpy32.d \
./hal/oa.d \
./hal/pmap.d \
./hal/pmm.d \
./hal/ram.d \
./hal/ref.d \
./hal/rtc_a.d \
./hal/rtc_b.d \
./hal/rtc_c.d \
./hal/sd24_b.d \
./hal/sfr.d \
./hal/sysctl.d \
./hal/tec.d \
./hal/timer_a.d \
./hal/timer_b.d \
./hal/timer_d.d \
./hal/tlv.d \
./hal/ucs.d \
./hal/usci_a_spi.d \
./hal/usci_a_uart.d \
./hal/usci_b_i2c.d \
./hal/usci_b_spi.d \
./hal/wdt_a.d 

OBJS += \
./hal/adc10_a.obj \
./hal/adc12_a.obj \
./hal/aes.obj \
./hal/battbak.obj \
./hal/comp_b.obj \
./hal/crc.obj \
./hal/ctsd16.obj \
./hal/dac12_a.obj \
./hal/dma.obj \
./hal/eusci_a_spi.obj \
./hal/eusci_a_uart.obj \
./hal/eusci_b_i2c.obj \
./hal/eusci_b_spi.obj \
./hal/flashctl.obj \
./hal/gpio.obj \
./hal/lcd_b.obj \
./hal/lcd_c.obj \
./hal/ldopwr.obj \
./hal/mpy32.obj \
./hal/oa.obj \
./hal/pmap.obj \
./hal/pmm.obj \
./hal/ram.obj \
./hal/ref.obj \
./hal/rtc_a.obj \
./hal/rtc_b.obj \
./hal/rtc_c.obj \
./hal/sd24_b.obj \
./hal/sfr.obj \
./hal/sysctl.obj \
./hal/tec.obj \
./hal/timer_a.obj \
./hal/timer_b.obj \
./hal/timer_d.obj \
./hal/tlv.obj \
./hal/ucs.obj \
./hal/usci_a_spi.obj \
./hal/usci_a_uart.obj \
./hal/usci_b_i2c.obj \
./hal/usci_b_spi.obj \
./hal/wdt_a.obj 

OBJS__QUOTED += \
"hal\adc10_a.obj" \
"hal\adc12_a.obj" \
"hal\aes.obj" \
"hal\battbak.obj" \
"hal\comp_b.obj" \
"hal\crc.obj" \
"hal\ctsd16.obj" \
"hal\dac12_a.obj" \
"hal\dma.obj" \
"hal\eusci_a_spi.obj" \
"hal\eusci_a_uart.obj" \
"hal\eusci_b_i2c.obj" \
"hal\eusci_b_spi.obj" \
"hal\flashctl.obj" \
"hal\gpio.obj" \
"hal\lcd_b.obj" \
"hal\lcd_c.obj" \
"hal\ldopwr.obj" \
"hal\mpy32.obj" \
"hal\oa.obj" \
"hal\pmap.obj" \
"hal\pmm.obj" \
"hal\ram.obj" \
"hal\ref.obj" \
"hal\rtc_a.obj" \
"hal\rtc_b.obj" \
"hal\rtc_c.obj" \
"hal\sd24_b.obj" \
"hal\sfr.obj" \
"hal\sysctl.obj" \
"hal\tec.obj" \
"hal\timer_a.obj" \
"hal\timer_b.obj" \
"hal\timer_d.obj" \
"hal\tlv.obj" \
"hal\ucs.obj" \
"hal\usci_a_spi.obj" \
"hal\usci_a_uart.obj" \
"hal\usci_b_i2c.obj" \
"hal\usci_b_spi.obj" \
"hal\wdt_a.obj" 

C_DEPS__QUOTED += \
"hal\adc10_a.d" \
"hal\adc12_a.d" \
"hal\aes.d" \
"hal\battbak.d" \
"hal\comp_b.d" \
"hal\crc.d" \
"hal\ctsd16.d" \
"hal\dac12_a.d" \
"hal\dma.d" \
"hal\eusci_a_spi.d" \
"hal\eusci_a_uart.d" \
"hal\eusci_b_i2c.d" \
"hal\eusci_b_spi.d" \
"hal\flashctl.d" \
"hal\gpio.d" \
"hal\lcd_b.d" \
"hal\lcd_c.d" \
"hal\ldopwr.d" \
"hal\mpy32.d" \
"hal\oa.d" \
"hal\pmap.d" \
"hal\pmm.d" \
"hal\ram.d" \
"hal\ref.d" \
"hal\rtc_a.d" \
"hal\rtc_b.d" \
"hal\rtc_c.d" \
"hal\sd24_b.d" \
"hal\sfr.d" \
"hal\sysctl.d" \
"hal\tec.d" \
"hal\timer_a.d" \
"hal\timer_b.d" \
"hal\timer_d.d" \
"hal\tlv.d" \
"hal\ucs.d" \
"hal\usci_a_spi.d" \
"hal\usci_a_uart.d" \
"hal\usci_b_i2c.d" \
"hal\usci_b_spi.d" \
"hal\wdt_a.d" 

C_SRCS__QUOTED += \
"../hal/adc10_a.c" \
"../hal/adc12_a.c" \
"../hal/aes.c" \
"../hal/battbak.c" \
"../hal/comp_b.c" \
"../hal/crc.c" \
"../hal/ctsd16.c" \
"../hal/dac12_a.c" \
"../hal/dma.c" \
"../hal/eusci_a_spi.c" \
"../hal/eusci_a_uart.c" \
"../hal/eusci_b_i2c.c" \
"../hal/eusci_b_spi.c" \
"../hal/flashctl.c" \
"../hal/gpio.c" \
"../hal/lcd_b.c" \
"../hal/lcd_c.c" \
"../hal/ldopwr.c" \
"../hal/mpy32.c" \
"../hal/oa.c" \
"../hal/pmap.c" \
"../hal/pmm.c" \
"../hal/ram.c" \
"../hal/ref.c" \
"../hal/rtc_a.c" \
"../hal/rtc_b.c" \
"../hal/rtc_c.c" \
"../hal/sd24_b.c" \
"../hal/sfr.c" \
"../hal/sysctl.c" \
"../hal/tec.c" \
"../hal/timer_a.c" \
"../hal/timer_b.c" \
"../hal/timer_d.c" \
"../hal/tlv.c" \
"../hal/ucs.c" \
"../hal/usci_a_spi.c" \
"../hal/usci_a_uart.c" \
"../hal/usci_b_i2c.c" \
"../hal/usci_b_spi.c" \
"../hal/wdt_a.c" 


