################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/tasks/antenna_deployment.c \
../app/tasks/downlink_manager.c \
../app/tasks/eps_server.c \
../app/tasks/heartbeat.c \
../app/tasks/obdh_server.c \
../app/tasks/radio_reset.c \
../app/tasks/read_antenna.c \
../app/tasks/read_sensors.c \
../app/tasks/startup.c \
../app/tasks/system_reset.c \
../app/tasks/tasks.c \
../app/tasks/time_control.c \
../app/tasks/uplink_manager.c \
../app/tasks/watchdog_reset.c 

C_DEPS += \
./app/tasks/antenna_deployment.d \
./app/tasks/downlink_manager.d \
./app/tasks/eps_server.d \
./app/tasks/heartbeat.d \
./app/tasks/obdh_server.d \
./app/tasks/radio_reset.d \
./app/tasks/read_antenna.d \
./app/tasks/read_sensors.d \
./app/tasks/startup.d \
./app/tasks/system_reset.d \
./app/tasks/tasks.d \
./app/tasks/time_control.d \
./app/tasks/uplink_manager.d \
./app/tasks/watchdog_reset.d 

OBJS += \
./app/tasks/antenna_deployment.obj \
./app/tasks/downlink_manager.obj \
./app/tasks/eps_server.obj \
./app/tasks/heartbeat.obj \
./app/tasks/obdh_server.obj \
./app/tasks/radio_reset.obj \
./app/tasks/read_antenna.obj \
./app/tasks/read_sensors.obj \
./app/tasks/startup.obj \
./app/tasks/system_reset.obj \
./app/tasks/tasks.obj \
./app/tasks/time_control.obj \
./app/tasks/uplink_manager.obj \
./app/tasks/watchdog_reset.obj 

OBJS__QUOTED += \
"app\tasks\antenna_deployment.obj" \
"app\tasks\downlink_manager.obj" \
"app\tasks\eps_server.obj" \
"app\tasks\heartbeat.obj" \
"app\tasks\obdh_server.obj" \
"app\tasks\radio_reset.obj" \
"app\tasks\read_antenna.obj" \
"app\tasks\read_sensors.obj" \
"app\tasks\startup.obj" \
"app\tasks\system_reset.obj" \
"app\tasks\tasks.obj" \
"app\tasks\time_control.obj" \
"app\tasks\uplink_manager.obj" \
"app\tasks\watchdog_reset.obj" 

C_DEPS__QUOTED += \
"app\tasks\antenna_deployment.d" \
"app\tasks\downlink_manager.d" \
"app\tasks\eps_server.d" \
"app\tasks\heartbeat.d" \
"app\tasks\obdh_server.d" \
"app\tasks\radio_reset.d" \
"app\tasks\read_antenna.d" \
"app\tasks\read_sensors.d" \
"app\tasks\startup.d" \
"app\tasks\system_reset.d" \
"app\tasks\tasks.d" \
"app\tasks\time_control.d" \
"app\tasks\uplink_manager.d" \
"app\tasks\watchdog_reset.d" 

C_SRCS__QUOTED += \
"../app/tasks/antenna_deployment.c" \
"../app/tasks/downlink_manager.c" \
"../app/tasks/eps_server.c" \
"../app/tasks/heartbeat.c" \
"../app/tasks/obdh_server.c" \
"../app/tasks/radio_reset.c" \
"../app/tasks/read_antenna.c" \
"../app/tasks/read_sensors.c" \
"../app/tasks/startup.c" \
"../app/tasks/system_reset.c" \
"../app/tasks/tasks.c" \
"../app/tasks/time_control.c" \
"../app/tasks/uplink_manager.c" \
"../app/tasks/watchdog_reset.c" 


