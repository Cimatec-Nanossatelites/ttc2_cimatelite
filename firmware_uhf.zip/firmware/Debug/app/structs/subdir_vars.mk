################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/structs/ttc_data.c 

C_DEPS += \
./app/structs/ttc_data.d 

OBJS += \
./app/structs/ttc_data.obj 

OBJS__QUOTED += \
"app\structs\ttc_data.obj" 

C_DEPS__QUOTED += \
"app\structs\ttc_data.d" 

C_SRCS__QUOTED += \
"../app/structs/ttc_data.c" 


