################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/libs/ngham-1.0/src/ccsds_scrambler.c \
../app/libs/ngham-1.0/src/crc_ccitt.c \
../app/libs/ngham-1.0/src/ngham.c \
../app/libs/ngham-1.0/src/ngham_extension.c \
../app/libs/ngham-1.0/src/ngham_packets.c 

C_DEPS += \
./app/libs/ngham-1.0/src/ccsds_scrambler.d \
./app/libs/ngham-1.0/src/crc_ccitt.d \
./app/libs/ngham-1.0/src/ngham.d \
./app/libs/ngham-1.0/src/ngham_extension.d \
./app/libs/ngham-1.0/src/ngham_packets.d 

OBJS += \
./app/libs/ngham-1.0/src/ccsds_scrambler.obj \
./app/libs/ngham-1.0/src/crc_ccitt.obj \
./app/libs/ngham-1.0/src/ngham.obj \
./app/libs/ngham-1.0/src/ngham_extension.obj \
./app/libs/ngham-1.0/src/ngham_packets.obj 

OBJS__QUOTED += \
"app\libs\ngham-1.0\src\ccsds_scrambler.obj" \
"app\libs\ngham-1.0\src\crc_ccitt.obj" \
"app\libs\ngham-1.0\src\ngham.obj" \
"app\libs\ngham-1.0\src\ngham_extension.obj" \
"app\libs\ngham-1.0\src\ngham_packets.obj" 

C_DEPS__QUOTED += \
"app\libs\ngham-1.0\src\ccsds_scrambler.d" \
"app\libs\ngham-1.0\src\crc_ccitt.d" \
"app\libs\ngham-1.0\src\ngham.d" \
"app\libs\ngham-1.0\src\ngham_extension.d" \
"app\libs\ngham-1.0\src\ngham_packets.d" 

C_SRCS__QUOTED += \
"../app/libs/ngham-1.0/src/ccsds_scrambler.c" \
"../app/libs/ngham-1.0/src/crc_ccitt.c" \
"../app/libs/ngham-1.0/src/ngham.c" \
"../app/libs/ngham-1.0/src/ngham_extension.c" \
"../app/libs/ngham-1.0/src/ngham_packets.c" 


