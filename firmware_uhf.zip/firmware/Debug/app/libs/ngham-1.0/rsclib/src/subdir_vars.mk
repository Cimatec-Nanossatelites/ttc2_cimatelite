################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/libs/ngham-1.0/rsclib/src/rsc.c 

C_DEPS += \
./app/libs/ngham-1.0/rsclib/src/rsc.d 

OBJS += \
./app/libs/ngham-1.0/rsclib/src/rsc.obj 

OBJS__QUOTED += \
"app\libs\ngham-1.0\rsclib\src\rsc.obj" 

C_DEPS__QUOTED += \
"app\libs\ngham-1.0\rsclib\src\rsc.d" 

C_SRCS__QUOTED += \
"../app/libs/ngham-1.0/rsclib/src/rsc.c" 


