################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/libs/fsp/fsp/crc16.c \
../app/libs/fsp/fsp/fsp.c 

C_DEPS += \
./app/libs/fsp/fsp/crc16.d \
./app/libs/fsp/fsp/fsp.d 

OBJS += \
./app/libs/fsp/fsp/crc16.obj \
./app/libs/fsp/fsp/fsp.obj 

OBJS__QUOTED += \
"app\libs\fsp\fsp\crc16.obj" \
"app\libs\fsp\fsp\fsp.obj" 

C_DEPS__QUOTED += \
"app\libs\fsp\fsp\crc16.d" \
"app\libs\fsp\fsp\fsp.d" 

C_SRCS__QUOTED += \
"../app/libs/fsp/fsp/crc16.c" \
"../app/libs/fsp/fsp/fsp.c" 


