################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/libs/fsat_pkt/fsat_pkt.c 

C_DEPS += \
./app/libs/fsat_pkt/fsat_pkt.d 

OBJS += \
./app/libs/fsat_pkt/fsat_pkt.obj 

OBJS__QUOTED += \
"app\libs\fsat_pkt\fsat_pkt.obj" 

C_DEPS__QUOTED += \
"app\libs\fsat_pkt\fsat_pkt.d" 

C_SRCS__QUOTED += \
"../app/libs/fsat_pkt/fsat_pkt.c" 


