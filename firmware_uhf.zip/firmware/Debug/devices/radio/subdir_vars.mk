################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../devices/radio/radio.c 

C_DEPS += \
./devices/radio/radio.d 

OBJS += \
./devices/radio/radio.obj 

OBJS__QUOTED += \
"devices\radio\radio.obj" 

C_DEPS__QUOTED += \
"devices\radio\radio.d" 

C_SRCS__QUOTED += \
"../devices/radio/radio.c" 


