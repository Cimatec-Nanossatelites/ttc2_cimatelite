# FIXED

devices/radio/radio.obj: ../devices/radio/radio.c
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/FreeRTOS.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stddef.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config/FreeRTOSConfig.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/projdefs.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/portable.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/deprecated_definitions.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/portable/CCS/MSP430X/portmacro.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5659.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/mpu_wrappers.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/task.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/list.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/system/sys_log/sys_log.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/drivers/si446x/si446x.h
devices/radio/radio.obj: C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdbool.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/drivers/si446x/si446x_registers.h
devices/radio/radio.obj: C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/devices/leds/leds.h
devices/radio/radio.obj: ../devices/radio/radio.h

../devices/radio/radio.c:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/FreeRTOS.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stddef.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_ti_config.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/linkage.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/_stdint40.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/cdefs.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_types.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/machine/_stdint.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/sys/_stdint.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/config/FreeRTOSConfig.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/projdefs.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/portable.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/deprecated_definitions.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/portable/CCS/MSP430X/portmacro.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430f5659.h:

C:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/mpu_wrappers.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/task.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/freertos/include/list.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/system/sys_log/sys_log.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/drivers/si446x/si446x.h:

C:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/stdbool.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/drivers/si446x/si446x_registers.h:

C:/Users/ramon.papes/Documents/cimatelite_github/ttc/ttc2_cimatelite/firmware/devices/leds/leds.h:

../devices/radio/radio.h:

