################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../devices/media/media.c 

C_DEPS += \
./devices/media/media.d 

OBJS += \
./devices/media/media.obj 

OBJS__QUOTED += \
"devices\media\media.obj" 

C_DEPS__QUOTED += \
"devices\media\media.d" 

C_SRCS__QUOTED += \
"../devices/media/media.c" 


