################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../devices/watchdog/watchdog.c 

C_DEPS += \
./devices/watchdog/watchdog.d 

OBJS += \
./devices/watchdog/watchdog.obj 

OBJS__QUOTED += \
"devices\watchdog\watchdog.obj" 

C_DEPS__QUOTED += \
"devices\watchdog\watchdog.d" 

C_SRCS__QUOTED += \
"../devices/watchdog/watchdog.c" 


