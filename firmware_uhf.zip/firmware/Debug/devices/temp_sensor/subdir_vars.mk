################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../devices/temp_sensor/temp_sensor.c 

C_DEPS += \
./devices/temp_sensor/temp_sensor.d 

OBJS += \
./devices/temp_sensor/temp_sensor.obj 

OBJS__QUOTED += \
"devices\temp_sensor\temp_sensor.obj" 

C_DEPS__QUOTED += \
"devices\temp_sensor\temp_sensor.d" 

C_SRCS__QUOTED += \
"../devices/temp_sensor/temp_sensor.c" 


