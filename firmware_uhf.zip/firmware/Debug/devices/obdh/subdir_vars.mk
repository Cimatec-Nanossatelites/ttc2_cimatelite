################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../devices/obdh/obdh.c 

C_DEPS += \
./devices/obdh/obdh.d 

OBJS += \
./devices/obdh/obdh.obj 

OBJS__QUOTED += \
"devices\obdh\obdh.obj" 

C_DEPS__QUOTED += \
"devices\obdh\obdh.d" 

C_SRCS__QUOTED += \
"../devices/obdh/obdh.c" 


