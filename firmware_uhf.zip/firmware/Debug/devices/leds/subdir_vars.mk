################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../devices/leds/leds.c 

C_DEPS += \
./devices/leds/leds.d 

OBJS += \
./devices/leds/leds.obj 

OBJS__QUOTED += \
"devices\leds\leds.obj" 

C_DEPS__QUOTED += \
"devices\leds\leds.d" 

C_SRCS__QUOTED += \
"../devices/leds/leds.c" 


