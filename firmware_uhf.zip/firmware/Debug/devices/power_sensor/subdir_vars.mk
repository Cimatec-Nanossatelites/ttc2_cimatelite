################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../devices/power_sensor/power_sensor.c 

C_DEPS += \
./devices/power_sensor/power_sensor.d 

OBJS += \
./devices/power_sensor/power_sensor.obj 

OBJS__QUOTED += \
"devices\power_sensor\power_sensor.obj" 

C_DEPS__QUOTED += \
"devices\power_sensor\power_sensor.d" 

C_SRCS__QUOTED += \
"../devices/power_sensor/power_sensor.c" 


