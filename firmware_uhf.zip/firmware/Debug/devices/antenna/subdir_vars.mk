################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../devices/antenna/antenna.c 

C_DEPS += \
./devices/antenna/antenna.d 

OBJS += \
./devices/antenna/antenna.obj 

OBJS__QUOTED += \
"devices\antenna\antenna.obj" 

C_DEPS__QUOTED += \
"devices\antenna\antenna.d" 

C_SRCS__QUOTED += \
"../devices/antenna/antenna.c" 


